﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BowlingBall.Tests
{
    [TestClass]
    public class GameFixture
    {
        Game game = new Game();

        [TestMethod]
        public void Gutter_game_score_should_be_zero_test()
        { 
            for (int frameNumber = 0; frameNumber < 10; frameNumber++)
                game.OpenFrame(0, 0);
            Assert.AreEqual(0, game.Score()); 
        }

        [TestMethod]
        public void AllThrees()
        {
            ManyOpenFrames(10, 3, 3);
            Assert.AreEqual(60, game.Score());
        }

        [TestMethod]
        public void Spare()
        {
            game.Spare(4, 6);
            game.OpenFrame(4, 5);
            ManyOpenFrames(8, 0, 0);
            Assert.AreEqual(13, game.Score());
        }

        [TestMethod]
        public void Strike()
        {
            game.Strike();
            game.OpenFrame(7, 2);
            ManyOpenFrames(4, 0, 0);
            Assert.AreEqual(18, game.Score());
        }

        [TestMethod]
        public void FinalStrike()
        {
            ManyOpenFrames(9, 0, 0);
            game.Strike();
            game.BonusRoll(5);
            game.BonusRoll(3);
            Assert.AreEqual(8, game.Score()); 
        }

        [TestMethod]
        public void FinalSpare()
        {
            ManyOpenFrames(9, 0, 0);
            game.Spare(4, 6);
            game.BonusRoll(5);
            Assert.AreEqual(5, game.Score());
        }
        private void ManyOpenFrames(int count, int firstThrow, int secondThrow)
        {
            for (int frameNumber = 0; frameNumber < count; frameNumber++)
                game.OpenFrame(firstThrow, secondThrow);
        }
    }
}
